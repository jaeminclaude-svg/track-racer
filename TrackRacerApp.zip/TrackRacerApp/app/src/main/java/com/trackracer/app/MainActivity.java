package com.trackracer.app;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;

public class MainActivity extends Activity {
    // 게임은 이 가상 주소로 열려서 저장 데이터(localStorage)가 업데이트 후에도 유지돼요.
    static final String HOST = "https://trackracer.local/";
    static final String THREE_URL = "https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js";

    private WebView web;
    private SharedPreferences sp;
    private long lastBack = 0;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("tr", MODE_PRIVATE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 28) {
            getWindow().getAttributes().layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        installBundled();

        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        web.setBackgroundColor(0xFF0B0F14);
        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return intercept(r.getUrl().toString());
            }
        });
        web.loadUrl(HOST + "index.html");
        checkUpdate();
    }

    // 앱에 들어 있는 게임이 내려받은 것보다 새 버전이면 교체
    private void installBundled() {
        try {
            long bundled = Long.parseLong(readAsset("version.txt").trim());
            File f = new File(getFilesDir(), "index.html");
            if (!f.exists() || bundled > sp.getLong("ver", 0)) {
                InputStream in = getAssets().open("index.html");
                writeFile(f, readAll(in));
                sp.edit().putLong("ver", bundled).apply();
            }
        } catch (Exception ignored) { }
    }

    private WebResourceResponse intercept(String url) {
        try {
            if (url.equals(HOST) || url.startsWith(HOST + "index.html")) {
                File f = new File(getFilesDir(), "index.html");
                InputStream in = f.exists() ? new FileInputStream(f) : getAssets().open("index.html");
                return new WebResourceResponse("text/html", "utf-8", in);
            }
            if (url.startsWith(HOST)) {
                return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
            }
            if (url.startsWith(THREE_URL)) {        // 3D 엔진은 한 번 내려받아 저장해 두고 이후엔 오프라인에서도 사용
                File f = new File(getFilesDir(), "three.min.js");
                if (!f.exists() && online()) {
                    byte[] d = http(THREE_URL);
                    if (d.length > 100000) writeFile(f, d);
                }
                if (f.exists()) return new WebResourceResponse("application/javascript", "utf-8", new FileInputStream(f));
            }
        } catch (Exception ignored) { }
        return null;
    }

    // 인터넷이 연결돼 있으면 새 게임 파일이 있는지 확인해서 내려받아요 (적용은 다음 실행 때)
    private void checkUpdate() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String u = readAsset("update_url.txt").trim();
                    if (u.isEmpty() || !online()) return;
                    JSONObject o = new JSONObject(new String(http(u), "UTF-8"));
                    long v = o.getLong("version");
                    if (v <= sp.getLong("ver", 0)) return;
                    String file = new URL(new URL(u), o.getString("file")).toString();
                    byte[] d = http(file);
                    String head = new String(d, 0, Math.min(d.length, 3000), "UTF-8").toLowerCase();
                    if (d.length < 100000 || !head.contains("<html")) return;
                    writeFile(new File(getFilesDir(), "index.html"), d);
                    sp.edit().putLong("ver", v).apply();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(MainActivity.this, "새 버전을 받았어요. 앱을 다시 켜면 적용돼요.", Toast.LENGTH_LONG).show();
                        }
                    });
                } catch (Exception ignored) { }
            }
        }).start();
    }

    private boolean online() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo n = cm.getActiveNetworkInfo();
            return n != null && n.isConnected();
        } catch (Exception e) { return false; }
    }

    private byte[] http(String u) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(20000);
        c.setInstanceFollowRedirects(true);
        try { return readAll(c.getInputStream()); } finally { c.disconnect(); }
    }

    private String readAsset(String n) throws Exception { return new String(readAll(getAssets().open(n)), "UTF-8"); }

    private static byte[] readAll(InputStream in) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int k;
        while ((k = in.read(buf)) > 0) out.write(buf, 0, k);
        in.close();
        return out.toByteArray();
    }

    private static void writeFile(File f, byte[] d) throws Exception {
        File t = new File(f.getPath() + ".tmp");
        FileOutputStream o = new FileOutputStream(t);
        o.write(d);
        o.close();
        if (!t.renameTo(f)) { f.delete(); t.renameTo(f); }
    }

    @Override
    public void onWindowFocusChanged(boolean has) {
        super.onWindowFocusChanged(has);
        if (has) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    @Override protected void onPause() { super.onPause(); if (web != null) web.onPause(); }
    @Override protected void onResume() { super.onResume(); if (web != null) web.onResume(); }

    @Override
    public void onBackPressed() {
        long now = System.currentTimeMillis();
        if (now - lastBack < 2000) { finish(); return; }
        lastBack = now;
        Toast.makeText(this, "한 번 더 누르면 종료돼요", Toast.LENGTH_SHORT).show();
    }
}
