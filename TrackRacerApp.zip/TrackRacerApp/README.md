# Track Racer 안드로이드 앱

## APK 만들기 (Android Studio 없이)
1. GitHub에 새 저장소를 만들고 이 폴더 전체를 올려요 (`.github` 폴더 포함).
2. 저장소의 Actions 탭에서 "Build APK"가 끝나면 Artifacts의 `TrackRacer-apk`를 내려받아요.
3. 안의 `app-debug.apk`를 폰/태블릿에 설치해요 (출처를 알 수 없는 앱 허용 필요).
(Android Studio로 열어 Build > Build APK 해도 돼요.)

## 인터넷 연결 시 자동 업데이트
- 같은 저장소의 `update.json` + `index.html`을 업데이트 파일로 써요.
- `app/src/main/assets/update_url.txt` 에 `update.json`의 raw 주소를 한 줄로 적고 APK를 빌드해요.
  예: https://raw.githubusercontent.com/내아이디/저장소/main/update.json
- 새 게임 버전을 올릴 때: 저장소 루트의 `index.html`을 새 파일로 바꾸고, `update.json`의 version 숫자를 키워서 올려요.
  (앱은 실행할 때 버전이 더 크면 index.html을 받아 두고, 다음 실행부터 적용해요. 저장 데이터는 유지돼요.)
- 앱 껍데기(APK) 자체는 이 방식으로 바뀌지 않아요. 게임 내용만 업데이트돼요.

## 알아둘 점
- 온라인 대전은 Claude 안에서만 동작해서 앱에서는 사용할 수 없어요.
- 3D 엔진(three.js)은 처음 실행할 때 인터넷으로 한 번 받아 저장해요. 그 뒤엔 오프라인도 돼요.
- 세이브 내보내기 파일 저장은 앱에서 안 될 수 있어요. 대신 "복사/붙여넣기" 코드를 쓰세요.
